import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import Header from '../components/Header';
import Footer from '../components/Footer';

const HomePage = () => {
  const { user } = useContext(AuthContext);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        {/* بنر اصلی */}
        <div className="primary-bg py-20 px-4">
          <div className="container mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">گلدان ثروت، آینده‌ای سبز برای ثروت شما!</h1>
            <p className="text-xl md:text-2xl mb-8">سرمایه‌گذاری مطمئن با سود روزانه</p>
            
            <div className="text-2xl md:text-3xl font-bold mb-6">
              <span>سود کل پرداخت‌شده: </span>
              <span className="primary-text">150,000 USDT</span>
            </div>
            
            {user ? (
              <div className="mb-8">
                <div className="text-xl mb-4">سود شما: <span className="primary-text">{user.totalProfit || 0} USDT</span></div>
                <Link to="/dashboard" className="accent-bg text-black font-bold py-3 px-8 rounded-md text-lg hover:opacity-90 transition-all">
                  مشاهده داشبورد
                </Link>
              </div>
            ) : (
              <div className="flex flex-col md:flex-row justify-center gap-4 mb-8">
                <Link to="/register" className="accent-bg text-black font-bold py-3 px-8 rounded-md text-lg hover:opacity-90 transition-all">
                  ثبت‌نام کن
                </Link>
                <Link to="/login" className="bg-gray-700 text-white font-bold py-3 px-8 rounded-md text-lg hover:opacity-90 transition-all">
                  ورود
                </Link>
              </div>
            )}
          </div>
        </div>
        
        {/* معرفی پلن‌ها */}
        <div className="py-16 px-4 bg-gray-800">
          <div className="container mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">پلن‌های سرمایه‌گذاری</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-gray-700 rounded-lg p-6 text-center">
                <h3 className="text-2xl font-bold mb-4">پلن نقره‌ای</h3>
                <p className="text-xl mb-2 primary-text">1,000 USDT</p>
                <p className="mb-4">سرمایه‌گذاری کم‌ریسک با سود روزانه</p>
                <Link to={user ? "/shop" : "/login"} className="inline-block accent-bg text-black font-bold py-2 px-6 rounded-md hover:opacity-90 transition-all">
                  {user ? "خرید" : "ورود برای مشاهده جزئیات"}
                </Link>
              </div>
              
              <div className="bg-gray-700 rounded-lg p-6 text-center">
                <h3 className="text-2xl font-bold mb-4">پلن طلایی</h3>
                <p className="text-xl mb-2 primary-text">5,000 USDT</p>
                <p className="mb-4">سرمایه‌گذاری با سود بالاتر</p>
                <Link to={user ? "/shop" : "/login"} className="inline-block accent-bg text-black font-bold py-2 px-6 rounded-md hover:opacity-90 transition-all">
                  {user ? "خرید" : "ورود برای مشاهده جزئیات"}
                </Link>
              </div>
              
              <div className="bg-gray-700 rounded-lg p-6 text-center">
                <h3 className="text-2xl font-bold mb-4">پلن الماسی</h3>
                <p className="text-xl mb-2 primary-text">10,000 USDT</p>
                <p className="mb-4">بالاترین سودآوری برای سرمایه‌گذاران حرفه‌ای</p>
                <Link to={user ? "/shop" : "/login"} className="inline-block accent-bg text-black font-bold py-2 px-6 rounded-md hover:opacity-90 transition-all">
                  {user ? "خرید" : "ورود برای مشاهده جزئیات"}
                </Link>
              </div>
            </div>
          </div>
        </div>
        
        {/* بخش نظرات */}
        <div className="py-16 px-4">
          <div className="container mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">نظرات کاربران</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-gray-700 rounded-lg p-6">
                <p className="mb-4">"سود منظم و رابط کاربری عالی! از وقتی با گلدان ثروت سرمایه‌گذاری کردم، هر روز سود دریافت می‌کنم."</p>
                <p className="font-bold">- رضا از تهران</p>
              </div>
              <div className="bg-gray-700 rounded-lg p-6">
                <p className="mb-4">"سیستم رفرال عالی! تونستم با معرفی دوستانم، درآمد اضافی کسب کنم. تشکر از گلدان ثروت!"</p>
                <p className="font-bold">- مریم از اصفهان</p>
              </div>
              <div className="bg-gray-700 rounded-lg p-6">
                <p className="mb-4">"پشتیبانی سریع و سیستم برداشت آسان. بدون دردسر، هر وقت خواستم برداشت کردم."</p>
                <p className="font-bold">- علی از مشهد</p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default HomePage;
