import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import { AuthContext } from './context/AuthContext';
import HomePage from './pages/HomePage';
import RegisterPage from './pages/RegisterPage';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import PlansPage from './pages/PlansPage';
import ShopPage from './pages/ShopPage';
import CheckoutPage from './pages/CheckoutPage';
import NoAccessPage from './pages/NoAccessPage';
import { checkAuth } from './utils/auth';

const App = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initAuth = async () => {
      try {
        const userData = await checkAuth();
        if (userData) {
          setUser(userData);
        }
      } catch (error) {
        console.error('خطا در بررسی وضعیت ورود:', error);
      } finally {
        setLoading(false);
      }
    };

    initAuth();
  }, []);

  // محافظ برای دسترسی به صفحات حساب کاربری
  const PrivateRoute = ({ component: Component, requiresActivePlan, ...rest }) => (
    <Route
      {...rest}
      render={(props) => {
        if (loading) {
          return <div className="flex justify-center items-center h-screen primary-bg">در حال بارگذاری...</div>;
        }

        if (!user) {
          return <Redirect to="/login" />;
        }

        if (requiresActivePlan && (!user.plans || user.plans.length === 0)) {
          return <Redirect to="/no-access" />;
        }

        return <Component {...props} />;
      }}
    />
  );

  return (
    <AuthContext.Provider value={{ user, setUser }}>
      <Router>
        <Switch>
          <Route path="/" exact component={HomePage} />
          <Route path="/register" component={RegisterPage} />
          <Route path="/login" component={LoginPage} />
          <Route path="/no-access" component={NoAccessPage} />
          <PrivateRoute path="/dashboard" component={DashboardPage} />
          <PrivateRoute path="/plans" component={PlansPage} requiresActivePlan={true} />
          <PrivateRoute path="/shop" component={ShopPage} />
          <PrivateRoute path="/checkout" component={CheckoutPage} />
          <Redirect to="/" />
        </Switch>
      </Router>
    </AuthContext.Provider>
  );
};

export default App;
