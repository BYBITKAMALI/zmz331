const Plan = require('../models/planModel');
const Profit = require('../models/profitModel');
const Wallet = require('../models/walletModel');
const Transaction = require('../models/transactionModel');
const { sendTelegramMessage } = require('../services/telegramService');
const { isWorkingDay } = require('../utils/dateUtils');

// دریافت همه طرح‌های فعال کاربر
exports.getUserPlans = async (req, res) => {
  try {
    const userId = req.user.id;
    const plans = await Plan.findAll({
      where: { userId, isActive: true },
      include: [{ model: Profit, where: { claimed: false }, required: false }]
    });
    
    res.status(200).json({ success: true, data: plans });
  } catch (error) {
    console.error('خطا در دریافت طرح‌ها:', error);
    res.status(500).json({ success: false, message: 'خطا در دریافت طرح‌ها' });
  }
};

// خرید طرح جدید
exports.purchasePlan = async (req, res) => {
  try {
    const { planType, paymentSource } = req.body;
    const userId = req.user.id;
    
    // بررسی معتبر بودن نوع طرح
    const planTypes = {
      silver: { price: 1000, title: 'نقره‌ای' },
      gold: { price: 5000, title: 'طلایی' },
      diamond: { price: 10000, title: 'الماسی' }
    };
    
    if (!planTypes[planType]) {
      return res.status(400).json({ success: false, message: 'نوع طرح نامعتبر است' });
    }
    
    // بررسی منبع پرداخت
    if (paymentSource !== 'main' && paymentSource !== 'instant') {
      return res.status(400).json({ success: false, message: 'منبع پرداخت نامعتبر است' });
    }
    
    // دریافت کیف پول کاربر
    const wallet = await Wallet.findOne({ where: { userId } });
    if (!wallet) {
      return res.status(404).json({ success: false, message: 'کیف پول یافت نشد' });
    }
    
    const price = planTypes[planType].price;
    const walletField = paymentSource === 'main' ? 'mainBalance' : 'instantBalance';
    
    // بررسی کافی بودن موجودی
    if (wallet[walletField] < price) {
      return res.status(400).json({ success: false, message: 'موجودی کافی نیست' });
    }
    
    // کم کردن از موجودی کیف پول
    wallet[walletField] -= price;
    await wallet.save();
    
    // ایجاد طرح جدید
    const now = new Date();
    const endDate = new Date();
    endDate.setDate(now.getDate() + 365); // طرح 365 روزه
    
    const plan = await Plan.create({
      userId,
      type: planType,
      title: planTypes[planType].title,
      investment: price,
      startDate: now,
      endDate: endDate,
      isActive: true
    });
    
    // ثبت تراکنش
    await Transaction.create({
      userId,
      type: 'plan_purchase',
      wallet: paymentSource,
      amount: price,
      description: `خرید طرح ${planTypes[planType].title}`,
      date: now
    });
    
    // ارسال پیام به تلگرام
    sendTelegramMessage(
      'users',
      `کاربر: ${req.user.email}, پلن: ${planTypes[planType].title}, مبلغ: ${price} USDT`
    );
    
    res.status(201).json({
      success: true,
      message: `طرح ${planTypes[planType].title} با موفقیت خریداری شد`,
      data: plan
    });
  } catch (error) {
    console.error('خطا در خرید طرح:', error);
    res.status(500).json({ success: false, message: 'خطا در خرید طرح' });
  }
};

// مشارکت در طرح (برای دریافت سود روزانه)
exports.participateInPlan = async (req, res) => {
  try {
    const { planId } = req.body;
    const userId = req.user.id;
    
    // بررسی روز کاری
    if (!isWorkingDay()) {
      return res.status(400).json({
        success: false,
        message: 'دریافت سود در روزهای کاری ممکن است'
      });
    }
    
    // بررسی وجود طرح
    const plan = await Plan.findOne({
      where: { id: planId, userId, isActive: true }
    });
    
    if (!plan) {
      return res.status(404).json({ success: false, message: 'طرح یافت نشد' });
    }
    
    // بررسی شرکت قبلی در همین روز
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const existingParticipation = await Profit.findOne({
      where: {
        planId,
        userId,
        date: today,
      }
    });
    
    if (existingParticipation) {
      return res.status(400).json({
        success: true,
        message: 'شما امروز در این طرح شرکت کرده‌اید',
        data: existingParticipation
      });
    }
    
    // محاسبه مقدار سود
    let profitAmount = calculateDailyProfit(plan);
    
    // ایجاد سود جدید
    const profit = await Profit.create({
      userId,
      planId,
      date: today,
      amount: profitAmount,
      claimed: false
    });
    
    res.status(201).json({
      success: true,
      message: `امروز ${profitAmount} USDT سود برای شما آماده شده`,
      data: profit
    });
  } catch (error) {
    console.error('خطا در مشارکت در طرح:', error);
    res.status(500).json({ success: false, message: 'خطا در مشارکت در طرح' });
  }
};

// دریافت سود
exports.claimProfit = async (req, res) => {
  try {
    const { profitId } = req.body;
    const userId = req.user.id;
    
    // بررسی وجود سود
    const profit = await Profit.findOne({
      where: { id: profitId, userId, claimed: false },
      include: [{ model: Plan }]
    });
    
    if (!profit) {
      return res.status(404).json({ success: false, message: 'سود یافت نشد یا قبلاً دریافت شده است' });
    }
    
    // دریافت کیف پول کاربر
    const wallet = await Wallet.findOne({ where: { userId } });
    if (!wallet) {
      return res.status(404).json({ success: false, message: 'کیف پول یافت نشد' });
    }
    
    // واریز سود به کیف پول اصلی
    wallet.mainBalance += profit.amount;
    await wallet.save();
    
    // علامت‌گذاری سود به عنوان دریافت شده
    profit.claimed = true;
    await profit.save();
    
    // ثبت تراکنش
    await Transaction.create({
      userId,
      type: 'profit',
      wallet: 'main',
      amount: profit.amount,
      description: `سود طرح ${profit.Plan.title}`,
      date: new Date()
    });
    
    res.status(200).json({
      success: true,
      message: `${profit.amount} USDT به کیف پول اصلی شما واریز شد`,
      data: { profit, wallet }
    });
  } catch (error) {
    console.error('خطا در دریافت سود:', error);
    res.status(500).json({ success: false, message: 'خطا در دریافت سود' });
  }
};

// تابع محاسبه سود روزانه
function calculateDailyProfit(plan) {
  const now = new Date();
  const startDate = new Date(plan.startDate);
  const diffTime = Math.abs(now - startDate);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  let profitAmount = 0;
  
  // محاسبه سود براساس روز قرارداد
  if (diffDays <= 60) {
    // 60 روز اول: سود = سرمایه تقسیم بر 40
    profitAmount = plan.investment / 40;
  } else if (diffDays <= 180) {
    // روز 61 تا 180: سود = 75% سود اولیه
    profitAmount = (plan.investment / 40) * 0.75;
  } else {
    // روز 181 تا 365: بستگی به وضعیت رفرال دارد
    // بررسی وضعیت رفرال (باید در لایه بیزینس انجام شود)
    const hasActiveReferrals = true; // این مقدار باید از دیتابیس بررسی شود
    
    if (hasActiveReferrals) {
      profitAmount = (plan.investment / 40) * 0.75; // 75% سود اولیه
    } else {
      profitAmount = (plan.investment / 40) * 0.5; // 50% سود اولیه
    }
  }
  
  return Math.round(profitAmount * 100) / 100; // گرد کردن تا دو رقم اعشار
}
