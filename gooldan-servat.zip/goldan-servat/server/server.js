const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const dotenv = require('dotenv');
const { errorHandler } = require('./middleware/errorHandler');
const userRoutes = require('./routes/userRoutes');
const walletRoutes = require('./routes/walletRoutes');
const planRoutes = require('./routes/planRoutes');
const referralRoutes = require('./routes/referralRoutes');
const adminRoutes = require('./routes/adminRoutes');
const { initTelegramBot } = require('./services/telegramService');
const { connectToDatabase } = require('./config/database');

// بارگذاری متغیرهای محیطی
dotenv.config();

// ایجاد برنامه اکسپرس
const app = express();
const PORT = process.env.PORT || 5000;

// راه‌اندازی میدلویرها
app.use(cors());
app.use(helmet());
app.use(express.json());
app.use(morgan('dev'));

// اتصال به دیتابیس
connectToDatabase();

// راه‌اندازی بات تلگرام
initTelegramBot();

// تنظیم روت‌ها
app.use('/api/users', userRoutes);
app.use('/api/wallets', walletRoutes);
app.use('/api/plans', planRoutes);
app.use('/api/referrals', referralRoutes);
app.use('/api/admin', adminRoutes);

// سرو فایل‌های استاتیک در حالت تولید
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../client/build')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/build', 'index.html'));
  });
}

// میدلویر مدیریت خطاها
app.use(errorHandler);

// راه‌اندازی سرور
app.listen(PORT, () => {
  console.log(`سرور در پورت ${PORT} در حال اجراست`);
});
